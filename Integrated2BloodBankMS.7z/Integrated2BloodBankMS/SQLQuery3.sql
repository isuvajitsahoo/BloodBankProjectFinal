create schema SuvaCoworkers
create table SuvaCoworkers.Coworkers
(
BookingID int identity(1000,1) primary key,
NameOfCompany varchar(255),
TANNumber varchar(20),
PANNumber varchar(20),
StartDate Date,
EndDate Date,
City varchar(20),
Center varchar(20)
)